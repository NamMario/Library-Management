﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManagerLibrary.ModelsViews
{
    internal enum BookStatus
    {
            Available = 0,
            Unavailable = -1,            
    }
}
